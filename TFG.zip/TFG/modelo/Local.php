<?php
require_once __DIR__ . '\DB.php';
class Local {

    private $_db, // Objeto de la clase DB
            $_data, // Datos del local
            $_sessionName, // Nombre de la sesión
            $_cookieName; // Nombre de la cookie

    
    // Constructor de la clase
    public function __construct() {
        // Se instancia la clase DB
        $this->_db = DB::getInstance();
        // Se obtienen el nombre de la sesión y el nombre de la cookie de la configuración
        $this->_sessionName = Config::get('session/session_name');
        $this->_cookieName = Config::get('remember/cookie_name');
    }

    // Método para crear un nuevo local
    public function create($fields = array()) {
        $tabla = "locales";
        // Se intenta insertar los datos del local en la base de datos
        if (!$this->_db->insert($tabla, $fields)) {
            throw new Exception('Ha habido un problema en la creación del local.');
        }
        return true;
    }

    // Método para actualizar los datos de un local
    public function update($fields = array(), $id = null) {
        // Si no se proporciona un ID y el local está logueado, se usa el ID del local actual
        if ($id) {
            $id = $this->data()->id;
        }
        // Se intenta actualizar los datos del local en la base de datos
        if (!$this->_db->update('locales', $id, $fields)) {
            throw new Exception('Ha habido un problema actualizando el local.');
        }
    }

    // Método para buscar un local por nombre de local 
    public function find($local = null) {
        if ($local) {
            // Se determina si el local es un nombre de local o un correo electrónico
            $field = (is_numeric($local)) ? 'local_id' : 'nombre_local' ;
            // Se busca el local en la base de datos
            $data = $this->_db->get('locales', array($field, '=', $local));

            // Si se encuentra el local, se almacenan sus datos en la propiedad _data
            if ($data->count()) {
                $this->_data = $data->first();
                return $this;
            }
        }
        return false;
    }

    // Método para obtener el ID de local a partir de un array de datos de local
    public function getLocalId($localArray) {
        if (!empty($localArray['nombre_local'])) {
            $tabla = "locales";
            $local = $this->_db->get($tabla, array('nombre_local', '=', $localArray['nombre_local']));
            if ($local->count() > 0) {
                return $local->first()->id;
            } else {
                return false; 
            }
        } else {
            return false; 
        }
    }

    // Método para obtener el nombre de local a partir de un ID de local
    public function getNombre_localById($localId) {
        if (!empty($localId)) {
            $tabla =  "locales";
            $local = $this->_db->get($tabla, array('local_id', '=', $localId));
            if ($local->count() > 0) {
                return $local->first()->nombre_local;
            } else {
                return false; 
            }
        } else {
            return false;
        }
    }

    // Método para obtener una lista de todos los locales
    public function allLocales() {
        $tabla = "locales";
        // Se ejecuta una consulta para obtener todos los locales de la base de datos
        if ($this->_db->query("SELECT * FROM " . $tabla)) {
            return $this->_db->query("SELECT * FROM " . $tabla);
        }
        // Si ocurre un error al ejecutar la consulta, se lanza una excepción
        if ($this->_db->query("SELECT * FROM " . $tabla)) {
            throw new Exception("Oops! Algo ha ido mal.");
        }
    }

    // Método para obtener una lista de locales con opciones de filtrado y ordenación
    public function allLocalesListUpgrade($fields = array(), $order = NULL) {
        $tabla = "locals";

        // Si no se proporcionan campos de filtrado, se obtienen todos los locales de la base de datos
        if ($fields == NULL) {
            if (!$this->_db->query("SELECT * FROM " . $tabla)) {
                throw new Exception("No se puede ejecutar la query.");
            }
            return $this->_db->query("SELECT * FROM " . $tabla);
        } else {
            // Si se proporcionan campos de filtrado, se ejecuta una consulta con estos campos y la ordenación especificada
            if (!$this->_db->getByParams($tabla, $fields, $order)) {
                throw new Exception("No se puede ejecutar la query.");
            }
            return $this->_db->getByParams($tabla, $fields, $order);
        }
    }

    // Método para verificar si existe un local
    public function exists() {
        // Devuelve true si existen datos del local, de lo contrario, devuelve false
        return (!empty($this->_data)) ? true : false;
    }

    // Método para obtener los datos del local
    public function data() {
        return $this->_data;
    }

}
?>
